# Script name
Keleus

# Version
1.1

# Operative system compatibility
Windows

# Author
Alessandro Barro (alessandro.b0906@gmail.com)

# Disclaimer
This script has been coded for educational purpose only. Do not use this tool to damage, violate, outrage another person's privacy or the person itself. Do not attempt to violate the law with anything contained here. If you planned to use the tool for illegal purpose, then close this tool immediately! Alessandro Barro will not be responsible for your any illegal actions. The author of this material, or anyone else affiliated in any way, is not going to accept responsibility for your actions.

# Engine
Powered by Python
